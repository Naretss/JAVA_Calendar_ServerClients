/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clients;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

/**
 *
 * @author QueQ-002
 */
public class Parameter {
    public static String IPtext;
    public static String TextLogin;
    public static Socket clientSocket ; 
    public static DataInputStream dis ;
    public static DataOutputStream dos ;
    public static void Disconnect() throws IOException{
        System.out.println("Disconnect");
        dos.writeUTF("Logout");
        clientSocket.close();
        dis.close();
        dos.close();
    }
}
