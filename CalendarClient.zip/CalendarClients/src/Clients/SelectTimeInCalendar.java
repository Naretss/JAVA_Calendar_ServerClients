/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clients;

import com.toedter.calendar.IDateEvaluator;
import com.toedter.calendar.JCalendar;
import java.awt.Color;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.lang.System.Logger;
import java.lang.System.Logger.Level;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.WindowConstants;

/**
 *
 * @author QueQ-002
 */
public class SelectTimeInCalendar extends javax.swing.JFrame {

    Socket clientSocket ; 
    DataInputStream dis ;
    DataOutputStream dos ;
    public static String Textmeet ="";
    public SelectTimeInCalendar() {
        try { 
            initComponents();
            String text = "12.00-01.30 A.M.,01.30-02.00 A.M.,02.00-02.30 A.M.,02.30-03.00 A.M.,03.00-03.30 A.M.,03.30-04.00 A.M.,04.00-04.30 A.M.,04.30-05.00 A.M.,05.00-05.30 A.M.,05.30-06.00 A.M.,06.00-06.30 A.M.,06.30-07.00 A.M.,07.00-07.30 A.M.,07.30-08.00 A.M.,08.00-08.30 A.M.,08.30-09.00 A.M.,09.00-09.30 A.M.,09.30-10.00 A.M.,10.00-10.30 A.M.,10.30-11.00 A.M.,11.00-11.30 A.M.,11.30-12.00 P.M.,12.00-01.30 P.M.,01.30-02.00 P.M.,02.00-02.30 P.M.,02.30-03.00 P.M.,03.00-03.30 P.M.,03.30-04.00 P.M.,04.00-04.30 P.M.,04.30-05.00 P.M.,05.00-05.30 P.M.,05.30-06.00 P.M.,06.00-06.30 P.M.,06.30-07.00 P.M.,07.00-07.30 P.M.,07.30-08.00 P.M.,08.00-08.30 P.M.,08.30-09.00 P.M.,09.00-09.30 P.M.,09.30-10.00 P.M.,10.00-10.30 P.M.,10.30-11.00 P.M.,11.00-11.30 P.M.,11.30-12.00 A.M.";
            String[] TextTime = text.split(",");
            for(int i=0 ;i< TextTime.length ; i++){
                ComboTime.addItem(TextTime[i]);
            }
            
            Date date = new Date();
            SimpleDateFormat formatDate = new SimpleDateFormat("yyyy-MM-dd");
            String Datetext = formatDate.format(date);
            TextDate.setText(Datetext);
            GUIcalendar();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(SelectTimeInCalendar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        
    }
    private void GUIcalendar() throws IOException{
        Calendar maxCalendar = Calendar.getInstance ( );
        maxCalendar.set ( 2030, 11, 31 );
        Date maxDate = maxCalendar.getTime ( );

        Calendar minCalendar = Calendar.getInstance ( );
        minCalendar.set ( 2000, 0, 1 );
        Date minDate = minCalendar.getTime ( );
     
        JCalendar calendar = new JCalendar ( );
        calendar.setLocation ( 15, 15 );
        calendar.setSize (420, 400 );
        calendar.setDate ( new Date ( ) );
        calendar.setMaxSelectableDate ( maxDate );
        calendar.setMinSelectableDate ( minDate );
        
        
        calendar.getDayChooser().addPropertyChangeListener("day", new PropertyChangeListener() {
        public void propertyChange(PropertyChangeEvent e) {
                SimpleDateFormat formatDate = new SimpleDateFormat("yyyy-MM-dd");
                String strDate = formatDate.format(calendar.getDate());
                comboButtonAdditem(strDate);
                System.out.println( strDate ); 
                TextDate.setText(strDate);
            }
        });
        
        ///Highlight Calendar for date have activity
        Parameter.dos.writeUTF("CheckActivity,CheckActivity");
        String DateActivity = Parameter.dis.readUTF(); // 2020-02-20,2020-01-02,2020-01-03
        System.out.println("DateActivity :" + DateActivity);
        String[] ListItemDate = DateActivity.split(",");
        HighlightEvaluator evaluator = new HighlightEvaluator();
        for(int i = 0; i<ListItemDate.length ; i++){ // [2020-02-20,2020-01-02,..]
            String itemDate = ListItemDate[i]; // 2020-01-02
            String[] Datatime = itemDate.split("-");
            int year = Integer.parseInt(Datatime[0]);   //2020
            int month = Integer.parseInt(Datatime[1])-1 ;  //2
            int day = Integer.parseInt(Datatime[2]);    //20
            evaluator.add(createDate(year,month,day));
            //evaluator.add(createDate(2020,3,14));
        }
        calendar.getDayChooser().addDateEvaluator(evaluator);
        calendar.setCalendar(calendar.getCalendar());
        ///Highlight Calendar for date have activity
        
        panelCalendar.add ( calendar );
    }
    
    
    
    
    private static class HighlightEvaluator implements IDateEvaluator {

        private final List<Date> list = new ArrayList<>();

        public void add(Date date) {
            list.add(date);
        }

        @Override
        public boolean isSpecial(Date date) {
            return list.contains(date);
        }

        @Override
        public Color getSpecialForegroundColor() {
            return Color.red.darker();
        }

        @Override
        public Color getSpecialBackroundColor() {
            return Color.blue;
        }

        @Override
        public String getSpecialTooltip() {
            return "Highlighted event.";
        }

        @Override
        public boolean isInvalid(Date date) {
            return false;
        }

        @Override
        public Color getInvalidForegroundColor() {
            return null;
        }

        @Override
        public Color getInvalidBackroundColor() {
            return null;
        }

        @Override
        public String getInvalidTooltip() {
            return null;
        }
    }
    
    private Date createDate(int y,int m,int d) {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.YEAR, y);
        c.set(Calendar.MONTH, m);
        c.set(Calendar.DAY_OF_MONTH, d);
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return (c.getTime());
    }
    
    private void comboButtonAdditem(String Datetime){
        try {
            ComboTime.removeAllItems();
            Parameter.dos.writeUTF("CheckComboItem,"+Datetime); //CheckComboItem,2020-02-01
            String TextAllTimeOfday = Parameter.dis.readUTF(); //12.00-01.30 A.M.,01.30-02.00 A.M.
            String[] ListComboTime = TextAllTimeOfday.split(",");
            String text = "12.00-01.30 A.M.,01.30-02.00 A.M.,02.00-02.30 A.M.,02.30-03.00 A.M.,03.00-03.30 A.M.,03.30-04.00 A.M.,04.00-04.30 A.M.,04.30-05.00 A.M.,05.00-05.30 A.M.,05.30-06.00 A.M.,06.00-06.30 A.M.,06.30-07.00 A.M.,07.00-07.30 A.M.,07.30-08.00 A.M.,08.00-08.30 A.M.,08.30-09.00 A.M.,09.00-09.30 A.M.,09.30-10.00 A.M.,10.00-10.30 A.M.,10.30-11.00 A.M.,11.00-11.30 A.M.,11.30-12.00 P.M.,12.00-01.30 P.M.,01.30-02.00 P.M.,02.00-02.30 P.M.,02.30-03.00 P.M.,03.00-03.30 P.M.,03.30-04.00 P.M.,04.00-04.30 P.M.,04.30-05.00 P.M.,05.00-05.30 P.M.,05.30-06.00 P.M.,06.00-06.30 P.M.,06.30-07.00 P.M.,07.00-07.30 P.M.,07.30-08.00 P.M.,08.00-08.30 P.M.,08.30-09.00 P.M.,09.00-09.30 P.M.,09.30-10.00 P.M.,10.00-10.30 P.M.,10.30-11.00 P.M.,11.00-11.30 P.M.,11.30-12.00 A.M.";
            
            if(TextAllTimeOfday.contains("-")){ // result ex. 12.00-01.30 A.M. have character -
                for(int i=0 ; i<ListComboTime.length;i++ ){
                    if(text.contains(","+ListComboTime[i]+",")){
                        text=text.replace(","+ListComboTime[i]+",",",");
                    }
                    else if(text.contains(","+ListComboTime[i])){
                        text=text.replace(","+ListComboTime[i],"");
                    }
                    else if(text.contains(ListComboTime[i]+",")){
                        text=text.replace(ListComboTime[i]+",","");
                    }
                }
            }
            System.out.println("TextAllTimeOfday : "+ TextAllTimeOfday);
            System.out.println("TextTime : "+ text);
            String[] TextTime = text.split(",");
            for(int i=0 ;i< TextTime.length ; i++){
                ComboTime.addItem(TextTime[i]);
            }
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(SelectTimeInCalendar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        bg = new javax.swing.JPanel();
        Exit = new javax.swing.JLabel();
        panelCalendar = new javax.swing.JPanel();
        TextDate = new javax.swing.JLabel();
        TextDate1 = new javax.swing.JLabel();
        ComboTime = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        ConfirmCalendar = new javax.swing.JButton();
        TextDate2 = new javax.swing.JLabel();
        Act = new javax.swing.JButton();

        jLabel1.setText("jLabel1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setResizable(false);

        bg.setBackground(new java.awt.Color(54, 33, 89));

        Exit.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Exit.setForeground(new java.awt.Color(255, 255, 255));
        Exit.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Exit.setText("X");
        Exit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ExitMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout panelCalendarLayout = new javax.swing.GroupLayout(panelCalendar);
        panelCalendar.setLayout(panelCalendarLayout);
        panelCalendarLayout.setHorizontalGroup(
            panelCalendarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 442, Short.MAX_VALUE)
        );
        panelCalendarLayout.setVerticalGroup(
            panelCalendarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        TextDate.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        TextDate.setForeground(new java.awt.Color(255, 204, 0));
        TextDate.setText("jLabel1");

        TextDate1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        TextDate1.setForeground(new java.awt.Color(255, 255, 255));
        TextDate1.setText("Select Datetime :");

        ComboTime.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        ConfirmCalendar.setBackground(new java.awt.Color(255, 255, 255));
        ConfirmCalendar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        ConfirmCalendar.setText("Confirm ");
        ConfirmCalendar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ConfirmCalendarActionPerformed(evt);
            }
        });

        TextDate2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        TextDate2.setForeground(new java.awt.Color(255, 255, 255));
        TextDate2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        TextDate2.setText("Calendar for recording events");

        Act.setBackground(new java.awt.Color(255, 255, 255));
        Act.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        Act.setText("Activity");
        Act.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ActMouseClicked(evt);
            }
        });
        Act.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ActActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout bgLayout = new javax.swing.GroupLayout(bg);
        bg.setLayout(bgLayout);
        bgLayout.setHorizontalGroup(
            bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(bgLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(panelCalendar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(bgLayout.createSequentialGroup()
                        .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(bgLayout.createSequentialGroup()
                                .addComponent(TextDate1, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(TextDate, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(ComboTime, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(jScrollPane1))
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, bgLayout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(Act, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(ConfirmCalendar, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(20, 20, 20))
                    .addGroup(bgLayout.createSequentialGroup()
                        .addComponent(TextDate2, javax.swing.GroupLayout.DEFAULT_SIZE, 408, Short.MAX_VALUE)
                        .addContainerGap())))
            .addGroup(bgLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(Exit, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        bgLayout.setVerticalGroup(
            bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bgLayout.createSequentialGroup()
                .addComponent(Exit)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(bgLayout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(TextDate2, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(TextDate1, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(TextDate, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(ComboTime, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 251, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(ConfirmCalendar, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Act, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(39, Short.MAX_VALUE))
                    .addGroup(bgLayout.createSequentialGroup()
                        .addComponent(panelCalendar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(20, 20, 20))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bg, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void ExitMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitMouseClicked
        try {
            Parameter.Disconnect();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(CreateANewAccount.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        System.exit(0);
    }//GEN-LAST:event_ExitMouseClicked

    private void ConfirmCalendarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ConfirmCalendarActionPerformed
        String SelectDate = TextDate.getText();
        String SelectTime = (String) ComboTime.getSelectedItem();
        String Activity = jTextArea1.getText();
        String Esuemail = Parameter.TextLogin.split(",")[1];
        
        String OutputText = "Calendar"+","+SelectDate+","+SelectTime+","+Activity+","+Esuemail;
        if(!Esuemail.isEmpty() && !Activity.isEmpty())
        {
            try {
                Parameter.dos.writeUTF(OutputText);
                String status = Parameter.dis.readUTF(); 
                System.out.println(status);
                if(status.equals("success")){
                    Textmeet = "meet your tutor at "+SelectDate+" : "+SelectTime;
                    YourConfirmation pages = new YourConfirmation();
                    pages.setVisible(true);
                    setVisible(false);
                }
                else{
                    JOptionPane.showMessageDialog(null,"Create Activity failed."+status,"Alert",JOptionPane.WARNING_MESSAGE);
                }
            } catch (IOException ex) {
                java.util.logging.Logger.getLogger(SelectTimeInCalendar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
            }
        }else{
            JOptionPane.showMessageDialog(null,"Please provide the information in the given space.","Alert",JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_ConfirmCalendarActionPerformed

    private void ActActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ActActionPerformed
       
    }//GEN-LAST:event_ActActionPerformed

    private void ActMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ActMouseClicked
        Activity page = new Activity();
        page.setVisible(true);
        setVisible(false);
    }//GEN-LAST:event_ActMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SelectTimeInCalendar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SelectTimeInCalendar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SelectTimeInCalendar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SelectTimeInCalendar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SelectTimeInCalendar().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Act;
    private javax.swing.JComboBox<String> ComboTime;
    private javax.swing.JButton ConfirmCalendar;
    private javax.swing.JLabel Exit;
    private javax.swing.JLabel TextDate;
    private javax.swing.JLabel TextDate1;
    private javax.swing.JLabel TextDate2;
    private javax.swing.JPanel bg;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JPanel panelCalendar;
    // End of variables declaration//GEN-END:variables
}
