
package Clients;

import java.awt.event.KeyEvent;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;


public class CreateANewAccount extends javax.swing.JFrame {


    public CreateANewAccount() throws UnknownHostException, IOException {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        TextCreate = new javax.swing.JLabel();
        TextCreate2 = new javax.swing.JLabel();
        TextFirst = new javax.swing.JLabel();
        TextLast = new javax.swing.JLabel();
        TextStudent = new javax.swing.JLabel();
        TextEUSemail = new javax.swing.JLabel();
        TextPassword = new javax.swing.JLabel();
        FieldFirst = new javax.swing.JTextField();
        FieldLast = new javax.swing.JTextField();
        FieldESUemaill = new javax.swing.JTextField();
        FieldStudentID = new javax.swing.JTextField();
        ButtonCreate = new javax.swing.JButton();
        TextCreate3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        FieldPassword = new javax.swing.JPasswordField();
        Exit = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(54, 33, 89));

        TextCreate.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        TextCreate.setForeground(new java.awt.Color(255, 255, 255));
        TextCreate.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        TextCreate.setText("Create a new account");

        TextCreate2.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        TextCreate2.setForeground(new java.awt.Color(255, 255, 255));
        TextCreate2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        TextCreate2.setText("(ESU students only)");

        TextFirst.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        TextFirst.setForeground(new java.awt.Color(255, 255, 255));
        TextFirst.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        TextFirst.setText("First name");

        TextLast.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        TextLast.setForeground(new java.awt.Color(255, 255, 255));
        TextLast.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        TextLast.setText("Last name");

        TextStudent.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        TextStudent.setForeground(new java.awt.Color(255, 255, 255));
        TextStudent.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        TextStudent.setText("Student id");

        TextEUSemail.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        TextEUSemail.setForeground(new java.awt.Color(255, 255, 255));
        TextEUSemail.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        TextEUSemail.setText("ESU email");

        TextPassword.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        TextPassword.setForeground(new java.awt.Color(255, 255, 255));
        TextPassword.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        TextPassword.setText("Password");

        FieldFirst.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        FieldLast.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        FieldESUemaill.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        FieldStudentID.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        FieldStudentID.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                FieldStudentIDKeyPressed(evt);
            }
        });

        ButtonCreate.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        ButtonCreate.setText("Create account");
        ButtonCreate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonCreateActionPerformed(evt);
            }
        });

        TextCreate3.setForeground(new java.awt.Color(255, 255, 255));
        TextCreate3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        TextCreate3.setText("Please fill your information completely.");

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Clients/image/icons8_user_50px.png"))); // NOI18N

        FieldPassword.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        FieldPassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FieldPasswordActionPerformed(evt);
            }
        });

        Exit.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Exit.setForeground(new java.awt.Color(255, 255, 255));
        Exit.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Exit.setText("X");
        Exit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ExitMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(262, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(TextCreate, javax.swing.GroupLayout.PREFERRED_SIZE, 256, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(326, 326, 326))
                    .addComponent(Exit, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)))
            .addComponent(TextCreate2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(166, 166, 166)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(TextPassword)
                                    .addComponent(TextEUSemail)
                                    .addComponent(TextLast)
                                    .addComponent(TextFirst))
                                .addGap(19, 19, 19)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(FieldESUemaill, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 390, Short.MAX_VALUE)
                                    .addComponent(FieldLast, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(FieldFirst, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(FieldPassword, javax.swing.GroupLayout.Alignment.LEADING)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(TextStudent, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(FieldStudentID, javax.swing.GroupLayout.PREFERRED_SIZE, 390, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(366, 366, 366)
                        .addComponent(ButtonCreate)))
                .addContainerGap(240, Short.MAX_VALUE))
            .addComponent(TextCreate3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(TextCreate)
                            .addComponent(jLabel1)))
                    .addComponent(Exit, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(TextCreate2)
                .addGap(29, 29, 29)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(FieldFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(TextFirst))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(FieldLast, javax.swing.GroupLayout.DEFAULT_SIZE, 37, Short.MAX_VALUE)
                    .addComponent(TextLast))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(FieldESUemaill, javax.swing.GroupLayout.DEFAULT_SIZE, 37, Short.MAX_VALUE)
                    .addComponent(TextEUSemail))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(TextPassword)
                    .addComponent(FieldPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(13, 13, 13)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TextStudent)
                    .addComponent(FieldStudentID, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(46, 46, 46)
                .addComponent(ButtonCreate, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(TextCreate3)
                .addGap(58, 58, 58))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void ButtonCreateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonCreateActionPerformed
        String First_name = FieldFirst.getText();
        String Last_name = FieldLast.getText();
        String ESU_email = FieldESUemaill.getText().toLowerCase();
        String Password = String.valueOf(FieldPassword.getPassword());
        String Student_id = FieldStudentID.getText();
        String Text = "Create,"+First_name+","+Last_name+","+ESU_email+","+
        Password+","+Student_id;
        if(!FieldFirst.getText().isEmpty() && !FieldLast.getText().isEmpty() 
           && !FieldESUemaill.getText().isEmpty() && !Password.isEmpty()
           && !FieldStudentID.getText().isEmpty()
           )
        {
            try {
                String checkESU = "CheckESUemail,"+ESU_email;
                
                Parameter.dos.writeUTF(checkESU);
                String status_check_emty = Parameter.dis.readUTF();
                
                System.out.println(checkESU);
                System.out.println(status_check_emty);
                if(status_check_emty.equals("This email cannot be found.")){
                    Parameter.dos.writeUTF(Text); //Create,"+First_name+","+Last_name+","+ESU_email+","+Password+","+Student_id;
                    String status = Parameter.dis.readUTF(); 
                    System.out.println("Create User "+ status);
                    if(status.equals("success")){
                        YourAccountAlreadys pages = new YourAccountAlreadys();
                        pages.setVisible(true);
                        setVisible(false);
                    }
                }
                else{
                    JOptionPane.showMessageDialog(null,"This email already exists. Please enter another email.","Alert",JOptionPane.WARNING_MESSAGE);
                }
            }catch(IOException ex){
              System.out.println(ex);
              JOptionPane.showMessageDialog(null,"Connection failed.","Alert",JOptionPane.WARNING_MESSAGE);
            } 
        }
        else{
            JOptionPane.showMessageDialog(null,"Please provide the information in the given space.","Alert",JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_ButtonCreateActionPerformed

    private void FieldPasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FieldPasswordActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_FieldPasswordActionPerformed

    private void FieldStudentIDKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_FieldStudentIDKeyPressed
       if(evt.getKeyCode() == KeyEvent.VK_ENTER){
        String First_name = FieldFirst.getText();
        String Last_name = FieldLast.getText();
        String ESU_email = FieldESUemaill.getText();
        String Password = String.valueOf(FieldPassword.getPassword());
        String Student_id = FieldStudentID.getText();
        String Text = "Create,"+First_name+","+Last_name+","+ESU_email+","+
        Password+","+Student_id;
        if(!FieldFirst.getText().isEmpty() && !FieldLast.getText().isEmpty() 
           && !FieldESUemaill.getText().isEmpty() && !Password.isEmpty()
           && !FieldStudentID.getText().isEmpty()
           )
        {
            try {
                String checkESU = "CheckESUemail,"+ESU_email;
                
                Parameter.dos.writeUTF(checkESU);
                String status_check_emty = Parameter.dis.readUTF();
                
                System.out.println(checkESU);
                System.out.println(status_check_emty);
                if(status_check_emty.equals("This email cannot be found.")){
                    Parameter.dos.writeUTF(Text); //Create,"+First_name+","+Last_name+","+ESU_email+","+Password+","+Student_id;
                    String status = Parameter.dis.readUTF(); 
                    System.out.println("Create User "+ status);
                    if(status.equals("success")){
                        YourAccountAlreadys pages = new YourAccountAlreadys();
                        pages.setVisible(true);
                        setVisible(false);
                    }
                }
                else{
                    JOptionPane.showMessageDialog(null,"This email already exists. Please enter another email.","Alert",JOptionPane.WARNING_MESSAGE);
                }
            }catch(IOException ex){
              System.out.println(ex);
              JOptionPane.showMessageDialog(null,"Connection failed.","Alert",JOptionPane.WARNING_MESSAGE);
            } 
        }
        else{
            JOptionPane.showMessageDialog(null,"Please provide the information in the given space.","Alert",JOptionPane.WARNING_MESSAGE);
        }
       }
    }//GEN-LAST:event_FieldStudentIDKeyPressed

    private void ExitMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitMouseClicked
        try {
            Parameter.Disconnect();
        } catch (IOException ex) {
            Logger.getLogger(CreateANewAccount.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.exit(0);
    }//GEN-LAST:event_ExitMouseClicked

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new CreateANewAccount().setVisible(true);
                } catch (IOException ex) {
                    Logger.getLogger(CreateANewAccount.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ButtonCreate;
    private javax.swing.JLabel Exit;
    private javax.swing.JTextField FieldESUemaill;
    private javax.swing.JTextField FieldFirst;
    private javax.swing.JTextField FieldLast;
    private javax.swing.JPasswordField FieldPassword;
    private javax.swing.JTextField FieldStudentID;
    private javax.swing.JLabel TextCreate;
    private javax.swing.JLabel TextCreate2;
    private javax.swing.JLabel TextCreate3;
    private javax.swing.JLabel TextEUSemail;
    private javax.swing.JLabel TextFirst;
    private javax.swing.JLabel TextLast;
    private javax.swing.JLabel TextPassword;
    private javax.swing.JLabel TextStudent;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
