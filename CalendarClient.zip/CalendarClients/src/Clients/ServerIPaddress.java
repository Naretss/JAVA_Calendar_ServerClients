/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clients;
import java.io.*; 
import java.net.*; 
import java.util.Scanner; 
import java.awt.Color;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class ServerIPaddress extends javax.swing.JFrame {

    public ServerIPaddress() {
        initComponents();
        setBackground(Color.cyan);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bg = new javax.swing.JPanel();
        TextServer = new javax.swing.JLabel();
        InputIP = new javax.swing.JTextField();
        ClickConnect = new javax.swing.JButton();
        Textwelcome = new javax.swing.JLabel();
        icon = new javax.swing.JLabel();
        Exit = new javax.swing.JLabel();
        line = new javax.swing.JSeparator();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setUndecorated(true);
        setResizable(false);

        bg.setBackground(new java.awt.Color(54, 33, 89));
        bg.setInheritsPopupMenu(true);
        bg.setPreferredSize(new java.awt.Dimension(500, 900));

        TextServer.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        TextServer.setForeground(new java.awt.Color(255, 255, 255));
        TextServer.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        TextServer.setText("Server IP address");

        InputIP.setBackground(new java.awt.Color(204, 255, 255));
        InputIP.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        InputIP.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        InputIP.setText("127.0.0.1");
        InputIP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InputIPActionPerformed(evt);
            }
        });

        ClickConnect.setBackground(new java.awt.Color(255, 255, 255));
        ClickConnect.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        ClickConnect.setText("Click to connect to server");
        ClickConnect.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ClickConnectActionPerformed(evt);
            }
        });

        Textwelcome.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Textwelcome.setForeground(new java.awt.Color(255, 255, 255));
        Textwelcome.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Textwelcome.setText("Welcome to computer science tutoring program");

        icon.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Clients/image/icons8_calendar_100px_4.png"))); // NOI18N

        Exit.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Exit.setForeground(new java.awt.Color(255, 255, 255));
        Exit.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Exit.setText("X");
        Exit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ExitMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout bgLayout = new javax.swing.GroupLayout(bg);
        bg.setLayout(bgLayout);
        bgLayout.setHorizontalGroup(
            bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Textwelcome, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(icon, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, bgLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(Exit, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, bgLayout.createSequentialGroup()
                .addContainerGap(169, Short.MAX_VALUE)
                .addComponent(TextServer, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(InputIP, javax.swing.GroupLayout.PREFERRED_SIZE, 342, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(170, 170, 170))
            .addGroup(bgLayout.createSequentialGroup()
                .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(bgLayout.createSequentialGroup()
                        .addGap(181, 181, 181)
                        .addComponent(line, javax.swing.GroupLayout.PREFERRED_SIZE, 530, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(bgLayout.createSequentialGroup()
                        .addGap(298, 298, 298)
                        .addComponent(ClickConnect, javax.swing.GroupLayout.PREFERRED_SIZE, 251, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        bgLayout.setVerticalGroup(
            bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bgLayout.createSequentialGroup()
                .addComponent(Exit)
                .addGap(18, 18, 18)
                .addComponent(icon, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(3, 3, 3)
                .addComponent(Textwelcome)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(line, javax.swing.GroupLayout.PREFERRED_SIZE, 8, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(68, 68, 68)
                .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(InputIP, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(TextServer))
                .addGap(33, 33, 33)
                .addComponent(ClickConnect, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(115, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bg, javax.swing.GroupLayout.DEFAULT_SIZE, 900, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bg, javax.swing.GroupLayout.DEFAULT_SIZE, 500, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void InputIPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InputIPActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_InputIPActionPerformed

    private void ClickConnectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ClickConnectActionPerformed
        Parameter.IPtext = InputIP.getText();
        try{
            InetAddress ip = InetAddress.getByName(Parameter.IPtext);
            Parameter.clientSocket = new Socket(ip, 5056); 
            Parameter.dis = new DataInputStream(Parameter.clientSocket.getInputStream());
            Parameter.dos = new DataOutputStream(Parameter.clientSocket.getOutputStream());

            Welcome Welcomepage = new Welcome();
            Welcomepage.setVisible(true);
            setVisible(false);
        }catch(Exception ex){
            
          System.out.println(ex.getMessage());
          JOptionPane.showMessageDialog(null,"Connection failed","Alert",JOptionPane.WARNING_MESSAGE);
        }
        
    }//GEN-LAST:event_ClickConnectActionPerformed

    private void ExitMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitMouseClicked
        System.exit(0);
    }//GEN-LAST:event_ExitMouseClicked

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ServerIPaddress().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ClickConnect;
    private javax.swing.JLabel Exit;
    private javax.swing.JTextField InputIP;
    private javax.swing.JLabel TextServer;
    private javax.swing.JLabel Textwelcome;
    private javax.swing.JPanel bg;
    private javax.swing.JLabel icon;
    private javax.swing.JSeparator line;
    // End of variables declaration//GEN-END:variables
}
