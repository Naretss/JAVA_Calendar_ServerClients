import java.io.BufferedReader;
import java.io.FileNotFoundException; 
import java.io.FileReader; 
import java.io.FileWriter;
import java.io.IOException; 
class Test 
{ 
    public static void main(String[] args) throws IOException 
    { 
        String pathToCsv = "src/files/Calendar_1.csv";
        String DeleteRow = "2020-04-10,12.00-01.30 A.M.,gsdgsdg,naret@esu.com";
        String row;
        String AllRow="";
        BufferedReader csvReader = new BufferedReader(new FileReader(pathToCsv));
        while ((row = csvReader.readLine()) != null) {
            if(!row.equals(DeleteRow)){
                //System.out.println(row);
                AllRow = AllRow+row+"\n";
            }
        }
        System.out.print(AllRow);
        
        FileWriter pw = new FileWriter(pathToCsv);
        pw.append(AllRow);
        pw.flush();
        pw.close();
        System.out.println("Create user success");
        csvReader.close();
        
    } 
} 