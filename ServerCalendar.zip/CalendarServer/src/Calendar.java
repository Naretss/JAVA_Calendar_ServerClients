
import java.io.*;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
public class Calendar {
    public String pathToCsv = "src/files/Calendar.csv";
    public void CreateActivity(String lines) throws IOException{
        try{
            FileWriter pw = new FileWriter(pathToCsv,true);
                pw.append(lines+"\n");
                pw.flush();
                pw.close();
                System.out.println("Create user success");
        } catch (FileNotFoundException e) {
          System.out.println(e.getMessage());
        }
    }
    public String AllDate() throws IOException{
        String LineDate = "";
        BufferedReader csvReader;
        try {
            csvReader = new BufferedReader(new FileReader(pathToCsv));
            String row;
            int ForFirstItem=0;
            while ((row = csvReader.readLine()) != null){
                String[] data = row.split(",");
                String Dates = data[0];
                if(ForFirstItem==0){
                    ForFirstItem=1;
                }
                else if(ForFirstItem==1){
                    LineDate = Dates;
                    ForFirstItem=2;
                }
                else if(ForFirstItem==2){
                    LineDate = LineDate+ ","+Dates;
                }
            }
            csvReader.close();    
        }
        catch (FileNotFoundException ex) {
            Logger.getLogger(ProcessUser.class.getName()).log(Level.SEVERE, null, ex);
            return LineDate;
        }
        return LineDate;
         
    }
    
    public String AllTime(String clientDate) throws IOException{
        String LineTimes = ".";
        BufferedReader csvReader;
        try {
            csvReader = new BufferedReader(new FileReader(pathToCsv));
            String row;
            while ((row = csvReader.readLine()) != null){
                String[] data = row.split(",");
                String TextDate = data[0];
                String Times = data[1];
                
                if(clientDate.equals(TextDate)){
                    LineTimes = LineTimes+","+Times;
                    //System.out.println("clientDate : "+clientDate+ " == "+TextDate );
                    //System.out.println(Times);
                }
            }
            //LineTimes = LineTimes.substring(1);
            if (LineTimes != null && LineTimes.length() > 1) {
                LineTimes = LineTimes.substring(1);
                LineTimes = LineTimes.substring(1);
                System.out.println("LineTimes : "+ LineTimes.substring(1));
                System.out.println(LineTimes.substring(1));
            }
            csvReader.close();    
        }
        catch (FileNotFoundException ex) {
            Logger.getLogger(ProcessUser.class.getName()).log(Level.SEVERE, null, ex);
            return LineTimes;
        }
        return LineTimes;
         
    }
    
    public String ActivityUser(String UserEmail) throws IOException{
        String LineAct = "";
        BufferedReader csvReader;
        try {
            csvReader = new BufferedReader(new FileReader(pathToCsv));
            String row;
            while ((row = csvReader.readLine()) != null){
                
                String[] data = row.split(",");
                String TextDate = data[0];
                String Times = data[1];
                String TextAct = data[2];
                String email = data[3];
                // 2020-04-02,12.00-01.30 A.M.,test_text,job@esu.com&&2020-04-02,01.30-02.00 A.M.,test_text,job@esu.com
                if(UserEmail.equals(email)){
                    String temptext = TextDate+","+Times+","+TextAct+","+email;
                    LineAct = LineAct+"&&"+temptext;
                }
            }
            if (LineAct != null && LineAct.length() > 1) {
                LineAct = LineAct.substring(1);
                LineAct = LineAct.substring(1);
                System.out.println("LineDate : "+ LineAct);
            }
            csvReader.close();    
        }
        catch (FileNotFoundException ex) {
            Logger.getLogger(ProcessUser.class.getName()).log(Level.SEVERE, null, ex);
            return LineAct;
        }
        return LineAct;
         
    }
    public String DelectRow(String line) throws IOException{
        String status = "failed";
        try{
            String DeleteRow = line;
            String row;
            String AllRow="";
            BufferedReader csvReader = new BufferedReader(new FileReader(pathToCsv));
            while ((row = csvReader.readLine()) != null) {
                if(!row.equals(DeleteRow)){
                    //System.out.println(row);
                    AllRow = AllRow+row+"\n";
                }
            }
            System.out.print(AllRow);

            FileWriter pw = new FileWriter(pathToCsv);
            pw.append(AllRow);
            pw.flush();
            pw.close();
            System.out.println("Delete Success");
            status = "Delete Success";
            csvReader.close();
        }catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
            return status;
        }
        return status;
    }
    public String UpdateRow(String line) throws IOException{
        //System.out.println(line);
        String status = "failed";
        try{
            String[] check = line.split(",");
            String Checkrow = check[0]+","+check[1];
            String row;
            String AllRow="";
            BufferedReader csvReader = new BufferedReader(new FileReader(pathToCsv));
            while ((row = csvReader.readLine()) != null) {
                if(row.contains(Checkrow)){
                    AllRow = AllRow+line+"\n";
                }else{
                    AllRow = AllRow+row+"\n";
                }
            }
            //System.out.println("row all:"  +AllRow);
            FileWriter pw = new FileWriter(pathToCsv);
            pw.append(AllRow);
            pw.flush();
            pw.close();
            System.out.println("Update Success");
            status = "Update Success";
            csvReader.close();
        }catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
            return status;
        }
        return status;
    }
}
