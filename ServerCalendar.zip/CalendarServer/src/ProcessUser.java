
import java.io.*;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
public class ProcessUser {
    public String pathToCsv = "src/files/User.csv";
    public boolean Checks(String ESUid,String passwordESU) throws IOException{
        boolean status = false;
        BufferedReader csvReader;
        try {
            csvReader = new BufferedReader(new FileReader(pathToCsv));
            String row;
            while ((row = csvReader.readLine()) != null){
                String[] data = row.split(",");
                String First_name = data[0];
                String Last_name = data[1];
                String ESU_email = data[2];
                String Password = data[3];
                String Student_id = data[4];
                System.out.println(First_name+"|"+Last_name+"|"+ESU_email+"|"+Password+"|"+Student_id);
                if(ESU_email.equals(ESUid) && Password.equals(passwordESU)){
                    status = true;
                    return status;
                }
            }
            csvReader.close();    
        }
        catch (FileNotFoundException ex) {
            Logger.getLogger(ProcessUser.class.getName()).log(Level.SEVERE, null, ex);
            return status;
        }
        return status;
    }
    public void CreateUser(String lines) throws IOException{
        try{
            FileWriter pw = new FileWriter(pathToCsv,true);
                pw.append(lines+"\n");
                pw.flush();
                pw.close();
                System.out.println("Create user success");
        } catch (FileNotFoundException e) {
          System.out.println(e.getMessage());
        }
    }

    public boolean ChecksESUemail(String ESUid) throws IOException{
        boolean status = false;
        BufferedReader csvReader;
        try {
            csvReader = new BufferedReader(new FileReader(pathToCsv));
            String row;
            while ((row = csvReader.readLine()) != null){
                String[] data = row.split(",");
                String First_name = data[0];
                String Last_name = data[1];
                String ESU_email = data[2];
                String Password = data[3];
                String Student_id = data[4];
                System.out.println(First_name+"|"+Last_name+"|"+ESU_email+"|"+Password+"|"+Student_id);
                if(ESU_email.equals(ESUid)){
                    status = true;
                    return status;
                }
            }
            csvReader.close();    
        }
        catch (FileNotFoundException ex) {
            Logger.getLogger(ProcessUser.class.getName()).log(Level.SEVERE, null, ex);
            return status;
        }
        return status;
    }
}
