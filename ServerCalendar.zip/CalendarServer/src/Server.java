
import java.io.*; 
import java.text.*; 
import java.util.*; 
import java.net.*; 
import java.util.logging.Level;
import java.util.logging.Logger;
  
// Server class 
public class Server  
{
    public static void main(String[] args) throws IOException  
    { 
        // server is listening on port 5056 
        ServerSocket ss = new ServerSocket(5056); 
        System.out.println("-Start Server-");
        System.out.println("Ip server = "+InetAddress.getByName(null)+" port = 5056");
        while (true)  
        { 
            Socket s = null; 
            try 
            { 
                s = ss.accept(); 
                System.out.println("A new client is connected : " + s); 
                DataInputStream dis = new DataInputStream(s.getInputStream()); 
                DataOutputStream dos = new DataOutputStream(s.getOutputStream()); 
                  
                System.out.println("Assigning new thread for this client"); 
                Thread t = new ClientHandler(s, dis, dos); 
                t.start();  
            } 
            catch (Exception e){ 
                s.close(); 
                e.printStackTrace(); 
            } 
        } 
    } 
} 

class ClientHandler extends Thread  
{ 
    DateFormat fordate = new SimpleDateFormat("yyyy/MM/dd"); 
    DateFormat fortime = new SimpleDateFormat("hh:mm:ss"); 
    final DataInputStream dis; 
    final DataOutputStream dos; 
    final Socket s; 
      
  
    // Constructor 
    public ClientHandler(Socket s, DataInputStream dis, DataOutputStream dos)  
    { 
        this.s = s; 
        this.dis = dis; 
        this.dos = dos; 
    } 
  
    @Override
    public void run()  
    { 
        String received; 
        String toreturn; 
        while (true)  
        { 
            try { 
  
                // Ask user what he wants 
                //dos.writeUTF("Connection sussess"); 
                  
                // receive the answer from client 
                received = dis.readUTF(); 
                Calendar cld = new Calendar();  
                
                System.out.println("received "+received);
                if(received.equals("Logout")) 
                {  
                    System.out.println("Client " + this.s + " sends exit..."); 
                    System.out.println("Closing this connection."); 
                    this.s.close(); 
                    System.out.println("Connection closed"); 
                    break; 
                } else if(received.contains(",")){
                    String[] temp  = received.split(",");
                    String process = temp[0];
                    switch (process) { 
                        case "Login" : //Login,Esueamil,password
                            String Esueamil = temp[1];
                            String password = temp[2];
                            ProcessUser cu = new ProcessUser();
                            boolean checkuser =  cu.Checks(Esueamil,password);
                            System.out.println("Login: "+checkuser);
                            if(checkuser){
                                dos.writeUTF("success");
                            }
                            else{
                                dos.writeUTF("failed");    
                            }
                            break;
                        case "Create" : //Create,First_name,Last_name,ESU_email,Password,Student_id
                            String First_name = temp[1];
                            String Last_name = temp[2];
                            String ESU_email = temp[3];
                            String Password = temp[4];
                            String Student_id = temp[5];
                            String line = First_name+","+Last_name+","+ESU_email+","+
                            Password+","+Student_id;
                            ProcessUser cs = new ProcessUser();
                            try{
                                cs.CreateUser(line);
                                dos.writeUTF("success");
                            }catch(Exception ex){
                                dos.writeUTF("failed");
                            }
                            break;
                        case "CheckESUemail" : //CheckESUemail,Esueamil
                            String Esu = temp[1];
                            ProcessUser checks = new ProcessUser();
                            boolean check =  checks.ChecksESUemail(Esu);
                            System.out.println("CheckESUemail: "+check);
                            if(check){
                                dos.writeUTF("Already have this mail");
                            }
                            else{
                                dos.writeUTF("This email cannot be found.");    
                            }
                            break;
                        case "Calendar" : //Calendar,Date,Time,Text_Activity,ESU_email
                            String Date = temp[1];
                            String Time = temp[2];
                            String Text_Activity = temp[3];
                            String ESUemail = temp[4];
                            String TextLineCalendar = Date+','+Time+','+Text_Activity+','+ESUemail;
                            try{
                                cld.CreateActivity(TextLineCalendar);
                                dos.writeUTF("success");
                            }catch(Exception ex){
                                dos.writeUTF("failed");
                            }
                            break;
                        case "CheckActivity" :
                            System.out.println("--CheckActivity---");
                            String LineDate = cld.AllDate();
                            System.out.println("LineDate:" +LineDate);
                            try{
                                dos.writeUTF(LineDate);
                            }catch(Exception ex){
                                dos.writeUTF("failed");
                            }
                            break;
                        case "CheckComboItem":
                            String TextDate = temp[1];
                            String Linetime = cld.AllTime(TextDate);
                            System.out.println("Linetime : "+Linetime);
                            try{
                                dos.writeUTF(Linetime);  // 07.00-07.30 P.M.,......,....
                            }catch(Exception ex){
                                dos.writeUTF("failed");
                            }
                            break;
                        case "ActivityOfUser": //ActivityOfUser,naret@esu.com
                            String email = temp[1];
                            String LineAct = cld.ActivityUser(email);
                            System.out.println("Linetime : "+LineAct);
                            try{
                                dos.writeUTF(LineAct);  // / 2020-04-02,12.00-01.30 A.M.,test_text,job@esu.com&&2020-04-02,01.30-02.00 A.M.,test_text,job@esu.com
                            }catch(Exception ex){
                                dos.writeUTF("failed");
                            }
                            break;
                        case "DelectAct": //DelectAct,Date,Time,Text_Activity,ESU_email
                            String DateText = temp[1];
                            String TimeText = temp[2];
                            String Activity = temp[3];
                            String Email = temp[4];
                            String LineDelete = DateText+","+TimeText+","+Activity+","+Email;
                            String status =  cld.DelectRow(LineDelete);
                            try{
                                if(status.equals("Delete Success")){
                                     dos.writeUTF("Delete Success");
                                }else{
                                    dos.writeUTF("failed");
                                }
                            }catch(Exception ex){
                                dos.writeUTF("failed");
                            }
                            break;
                        case "UpdateCalendar": //UpdateCalendar,Date,Time,Text_Activity,ESU_email
                            String DateTextupdate = temp[1];
                            String TimeTextupdate = temp[2];
                            String Activityupdate = temp[3];
                            String Emailupdate = temp[4];
                            String LineUpdate = DateTextupdate+","+TimeTextupdate+","+Activityupdate+","+Emailupdate;
                            String statusUpdate =  cld.UpdateRow(LineUpdate);
                            try{
                                if(statusUpdate.equals("Update Success")){
                                     dos.writeUTF("Update Success");
                                }else{
                                    dos.writeUTF("failed");
                                }
                            }catch(Exception ex){
                                dos.writeUTF("failed");
                            }
                            break;
                        default: 
                            dos.writeUTF("Invalid input"); 
                            break; 
                    } 
                }
                  
                // creating Date object 

            } catch (IOException e) { 
                e.printStackTrace(); 
            } 
        } 
          
        try
        { 
            // closing resources 
            this.dis.close(); 
            this.dos.close(); 
              
        }catch(IOException e){ 
            e.printStackTrace(); 
        } 
    } 
} 